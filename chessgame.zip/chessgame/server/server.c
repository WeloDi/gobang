#include "function.h"

int epfd;
struct epoll_event ev, event[1024];
int pair;
Node clientinfo[CONNECT_MAX]; // 客户端信息

int main(int argc, char const *argv[])
{
    if (argc != 3) {
        fprintf(stderr, "Usage:%s <port>\n", argv[0]);
        return 0;
    }

    int sockfd = set_socket(argv[1], argv[2]);
    init(sockfd, &epfd, &ev, &pair, clientinfo);

    while (1) {
        int nreadys;
        if ((nreadys = epoll_wait(epfd, event, 100, -1)) == -1) {
            ERRLOG("epoll_wait");
        }
        if (nreadys == 0) {
            printf("timeout...\n");
        }

        for (int i = 0; i < nreadys; i++) // 遍历所有返回的事件
        {
            if (event[i].data.fd == sockfd) {
                newClient(sockfd, epfd, &ev, clientinfo);
            } else {
                handler_client(i, epfd, event, &ev, clientinfo, &pair);
            }
        }
    }
}
