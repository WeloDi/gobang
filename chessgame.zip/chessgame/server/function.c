#include "function.h"

/*创建服务器并开始监听，返回套接字*/
int set_socket(const char *IP, const char *Port)
{
    // 创建socket
    int sockfd = -1;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
        ERRLOG("socket");

    // 创建服务器的网络信息结构体
    struct sockaddr_in serveraddr;
    int addrlen = sizeof(serveraddr);
    memset(&serveraddr, 0, sizeof(struct sockaddr_in));
    serveraddr.sin_family = AF_INET;
    serveraddr.sin_port = htons(atoi(Port));
    serveraddr.sin_addr.s_addr = inet_addr(IP);

    int option = 1;
    if (-1 == setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &option, sizeof(option))) {
        ERRLOG("setsockopt");
    }
    struct timeval tm;
    tm.tv_sec = 5;
    tm.tv_usec = 0;
    if (-1 == setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tm, sizeof(tm)))
        ERRLOG("setsockopt");

    // 绑定socket和网络信息结构体
    if (bind(sockfd, (struct sockaddr *)&serveraddr, addrlen) == -1)
        ERRLOG("bind");

    // 开启监听
    if (listen(sockfd, 5) == -1)
        ERRLOG("listen");

    printf("--------------------------<服务器已开启>-------------------------\n");
    return sockfd;
}

void init(int sockfd, int *epfd, struct epoll_event *ev, int *pair, Node *clientinfo)
{
    if ((*epfd = epoll_create(1)) == -1)
        ERRLOG("epoll_create");

    ev->data.fd = sockfd;
    ev->events = EPOLLIN;
    epoll_ctl(*epfd, EPOLL_CTL_ADD, sockfd, ev);
    *pair = 0;
    memset(clientinfo, 0, sizeof(Node) * CONNECT_MAX);
}

void newClient(int sockfd, int epfd, struct epoll_event *ev, Node *clientinfo)
{
    struct sockaddr_in clientaddr;
    socklen_t addrlen = sizeof(clientaddr);
    int clientfd = accept(sockfd, (struct sockaddr *)&clientaddr, &addrlen);
    if (!clientfd)
        ERRLOG("accept");
    printf("客户端:[IP] %s\t[Port] %d  连接成功\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));

    ev->data.fd = clientfd;
    epoll_ctl(epfd, EPOLL_CTL_ADD, clientfd, ev); // 将新的客户端链接加入到epoll中

    for (int k = 0; k < CONNECT_MAX; k++) { // 将新的客户端连接加入到数组中保存
        if (clientinfo[k].status == 0) {
            clientinfo[k].clientfd = clientfd;
            clientinfo[k].status = 3;
            break;
        }
    }

    for (int k = 0; k < CONNECT_MAX; k++) {
        printf("fd:%d    mark:%d     status:%d\n", clientinfo[k].clientfd, clientinfo[k].mark, clientinfo[k].status);
    }
}

void handler_client(int i, int epfd, struct epoll_event *event, struct epoll_event *ev, Node *clientinfo, int *pair)
{
    int clientfd = event[i].data.fd; // 获取当前连接

    MSG msg;
    memset(&msg, 0, sizeof(MSG));
    int ret = recv(clientfd, &msg, sizeof(MSG), 0);
    if (ret == 0) {
        disConnected(clientfd, epfd, ev, clientinfo);
    } else {
        switch (msg.cmd) {
        case 1:
            createRoom(clientfd, pair, clientinfo);
            break;
        case 2:
            recvPos(clientfd, &msg, clientinfo);
            break;
        case 3:
            recvPos(clientfd, &msg, clientinfo);
            break;
        default:
            break;
        }
    }
}

void disConnected(int clientfd, int epfd, struct epoll_event *ev, Node *clientinfo)
{
    printf("连接关闭:%d\n", clientfd);
    close(clientfd);
    ev->events = EPOLLIN;
    ev->data.fd = clientfd;
    epoll_ctl(epfd, EPOLL_CTL_DEL, clientfd, ev);
    for (int j = 0; j < CONNECT_MAX; j++) {
        if (clientinfo[j].clientfd != clientfd) {
            clientinfo[j].clientfd = 0;
            clientinfo[j].mark = 0;
            clientinfo[j].status = 0;
        }
    }
}

void createRoom(int clientfd, int *pair, Node *clientinfo)
{
    int index;
    MSG replay;
    memset(&replay, 0, sizeof(MSG));
    /*将自身状态设置为寻找对局*/
    for (int j = 0; j < CONNECT_MAX; j++) {
        if (clientinfo[j].clientfd == clientfd && clientinfo[j].status == 3) {
            clientinfo[j].status = 2;
            index = j;
            break;
        }
    }

    /*寻找相同状态的其他客户端*/
    for (int m = 0; m < CONNECT_MAX; m++) {
        if (clientinfo[m].clientfd != clientfd && clientinfo[m].status == 2) {
            clientinfo[m].mark = ++(*pair);
            clientinfo[index].mark = *pair;

            replay.cmd = 101;
            if (send(clientfd, &replay, sizeof(MSG), 0) == -1)
                ERRLOG("send");

            replay.cmd = 100;
            if (send(clientinfo[m].clientfd, &replay, sizeof(MSG), 0) == -1)
                ERRLOG("send");

            clientinfo[m].status = 1;
            clientinfo[index].status = 1;
            printf("配对完成 mark:%d (fd:%d staus:%d——fd:%d  staus:%d)\n", clientinfo[m].mark, clientfd, clientinfo[index].status, clientinfo[m].clientfd, clientinfo[m].status);
            return;
        }
    }

    replay.cmd = 0;
    if (send(clientfd, &replay, sizeof(MSG), 0) == -1)
        ERRLOG("send");
    return;
}

void recvPos(int clientfd, MSG *msg, Node *clientinfo)
{
    // 获取自身下标
    int index;
    for (int i = 0; i < CONNECT_MAX; i++) {
        if (clientinfo[i].clientfd == clientfd) {
            index = i;
            printf("收到来自 fd=%d 的消息:cmd--%d   x--%d    y--%d\n", clientinfo[i].clientfd, msg->cmd, msg->x, msg->y);
            break;
        }
    }

    // 给对方客户端发送坐标
    if (msg->cmd == 2) {
        msg->cmd = 200;
    } else if (msg->cmd == 3)
        msg->cmd = 300;

    for (int j = 0; j < CONNECT_MAX; j++) {
        printf("fd:%d   mark:%d     status:%d\n", clientinfo[j].clientfd, clientinfo[j].mark, clientinfo[j].status);
        if (clientinfo[index].mark == clientinfo[j].mark && clientinfo[j].clientfd != clientfd) {
            send(clientinfo[j].clientfd, msg, sizeof(MSG), 0);
            // 恢复空闲状态
            if (msg->cmd == 300) {
                clientinfo[j].status = 3;
                clientinfo[j].mark = 0;
                clientinfo[index].status = 3;
                clientinfo[index].mark = 0;
            }
            printf("发送给%d >>x:%d  y:%d  cmd:%d\n", clientinfo[j].clientfd, msg->x, msg->y, msg->cmd);
            return;
        }
    }
    return;
}