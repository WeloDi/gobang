#ifndef FUNCTION_H
#define FUNCTION_H
#include <arpa/inet.h>
#include <errno.h>
#include <error.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#define CONNECT_MAX 4
#define ERRLOG(errmsg)                                                            \
    do {                                                                          \
        perror(errmsg);                                                           \
        printf("file : %s, func: %s, line : %d\n", __FILE__, __func__, __LINE__); \
        exit(-1);                                                                 \
    } while (0);

typedef struct MSG {
    int x;
    int y;
    int cmd; //  100:黑子  101:白子  200:发送位置    300:发送位置并且对局结束
} MSG;

typedef struct Node {
    int clientfd;
    int mark;   // 用于玩家匹配
    int status; //      1:游戏中   2:匹配中     3:空闲中
} Node;

int set_socket(const char *IP, const char *Port);
void init(int sockfd, int *epfd, struct epoll_event *ev, int *pair, Node *clientinfo);
void newClient(int sockfd, int epfd, struct epoll_event *ev, Node *clientinfo);
void handler_client(int i, int epfd, struct epoll_event *event, struct epoll_event *ev, Node *clientinfo, int *pair);
void disConnected(int clientfd, int epfd, struct epoll_event *ev, Node *clientinfo);
void createRoom(int clientfd, int *pair, Node *clientinfo);
void recvPos(int clientfd, MSG *msg, Node *clientinfo);
#endif