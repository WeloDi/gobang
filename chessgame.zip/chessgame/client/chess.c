#include "chess.h"

int getNum()
{
    char input[2];
    int index;
    char c;
    fgets(input, sizeof(input), stdin);
    sscanf(input, "%d", &index);
    while ((c = getchar()) != '\n' && c != EOF) {
    }
    return index;
}
void init_window()
{
    setlocale(LC_ALL, "");                                     // 中文支持
    initscr();                                                 // 初始化窗口
    noecho();                                                  // 关闭回显
    raw();                                                     // 阻止字符缓冲
    start_color();                                             // 使用颜色
    curs_set(0);                                               // 屏蔽字符指针
    mouseinterval(0);                                          // 设置鼠标事件检测的时间间隔
    keypad(stdscr, TRUE);                                      // 启用键盘映射，允许读取特殊键码
    mousemask(ALL_MOUSE_EVENTS | REPORT_MOUSE_POSITION, NULL); // 检测所有鼠标事件
    return;
}

int menu()
{
    clear(); // 清空屏幕
    int cur_x = CUR_X_CENTER;
    int cur_y = CUR_Y_CENTER;
    char *title = "五       子      棋";
    char *Option1 = "人机对战";
    char *Option2 = "玩家对战";
    char *Option3 = "退出游戏";
    char *cur1 = ">";
    char *cur2 = "<";
    init_pair(1, COLOR_BLACK, COLOR_WHITE); // 设置颜色对
    init_pair(2, COLOR_WHITE, COLOR_BLACK);
    mvprintw(cur_y / 2, cur_x - strlen(title) / 2, title);
    mvprintw(cur_y, cur_x - strlen(Option1) / 2, Option1);
    mvprintw(cur_y + 2, cur_x - strlen(Option2) / 2, Option2);
    mvprintw(cur_y + 4, cur_x - strlen(Option3) / 2, Option3);

    attron(COLOR_PAIR(1));
    mvaddstr(cur_y, cur_x - strlen(Option1) / 2 - 5, cur1);
    mvaddstr(cur_y, cur_x - strlen(Option1) / 2 + 12, cur2);
    attroff(COLOR_PAIR(1));
    refresh();

    int index;
    do {
        index = getch();
        // 清除当前光标
        attron(COLOR_PAIR(2));
        mvaddstr(cur_y, cur_x - strlen(Option1) / 2 - 5, " ");
        mvaddstr(cur_y, cur_x - strlen(Option1) / 2 + 12, " ");
        attroff(COLOR_PAIR(2));
        switch (index) {
        case KEY_UP: // 上
            if (cur_y <= LINES / 2) {
                cur_y = LINES / 2 + 4;
            } else {
                cur_y -= 2;
            }
            break;
        case KEY_DOWN: // 下
            if (cur_y >= LINES / 2 + 4) {
                cur_y = LINES / 2;
            } else {
                cur_y += 2;
            }
            break;
        default:
            break;
        }
        // 设置新光标
        attron(COLOR_PAIR(1));
        mvaddstr(cur_y, cur_x - strlen(Option1) / 2 - 5, cur1);
        mvaddstr(cur_y, cur_x - strlen(Option1) / 2 + 12, cur2);
        attroff(COLOR_PAIR(1));
    } while (index != 10);

    if (cur_y == CUR_Y_CENTER) {
        return 1;
    } else if (cur_y == CUR_Y_CENTER + 2) {
        return 2;
    }
    return 0;
}

void playerToComputer()
{
    clear();
    Chessman mychessman;
    Chessman Computerman;
    memset(&mychessman, 0, sizeof(mychessman));
    memset(&Computerman, 0, sizeof(Computerman));
    drawChessBoard("我", "电脑", 1);
    do {
        myMoveChess(-1, &mychessman, &Computerman, 1);
        computerMove();
        drawChessMan(&mychessman, NULL, &Computerman, 1);
    } while (1);
}

void playerToPlayer(int serverfd)
{
    clear();
    int flag;
    if ((flag = findGame(serverfd)) == -1) {
        return;
    }
    /* 创建聊天线程--接收*/
    // 初始化打印位置
    // 循环接收服务器传来的对方信息
    // 计算打印位置并打印
    // 打印完后，计算打印的字符数占几行，再将行数与上次行位置相加并记录保存
    // 如果已经到底，清空消息框，并重置打印位置

    /*创建聊天线程--发送*/
    // 判断鼠标点击事件
    // 判断鼠标位置是否在聊天框
    // 移动光标到聊天框首位置
    // 打开回显
    // 阻塞等待用户输入，输入完后回车确认发送（发送时判断输入是否为空）

    Chessman myself, enemy;
    memset(&myself, 0, sizeof(myself));
    memset(&enemy, 0, sizeof(enemy));

    clear();
    drawChessBoard("我", "TA", flag);
    do {
        // 我方落子
        if ((flag == 1 && myself.count == enemy.count) || (flag == 2 && myself.count < enemy.count)) {
            if (myMoveChess(serverfd, &myself, &enemy, flag)) {
                sleep(5);
                return;
            }
        }
        if (enemyMoveChess(serverfd, &enemy, flag)) {
            sleep(10);
            return;
        }
    } while (1);
}

/*name1:我的名字  name2:对方名字*   flag==1:我方黑子*/
void drawChessBoard(char *name1, char *name2, int flag)
{
    /*┌ ┬ ┐├ ┼ ┤└ ┴ ┘│─*/
    char *blank = "                                                                   ";
    init_pair(1, COLOR_BLACK, COLOR_YELLOW);
    init_pair(2, COLOR_WHITE, COLOR_YELLOW);

    attron(COLOR_PAIR(1));
    // 打印上边界
    for (int i = 1; i < 6; i++) {
        mvprintw(BOARD_START_Y - i, BOARD_START_X - 5, blank);
    }
    // 打印列标
    for (int i = 0; i < COLUMN; i++) {
        mvprintw(BOARD_START_Y - 1, BOARD_START_X + 4 * i, "%c", 65 + i);
    }
    // 打印行标
    for (int i = 0; i < ROW * 2; i++) {
        if (i % 2 == 0) {
            mvprintw(BOARD_START_Y + i, BOARD_START_X - 5, "  %02d ", i / 2 + 1);
        } else
            mvprintw(BOARD_START_Y + i, BOARD_START_X - 5, "     ");
    }

    for (int i = 0; i <= ROW * 2 - 2; i++) {
        for (int j = 0; j <= COLUMN * 4 - 4; j++) {
            // 第一行
            if (i == 0) {
                if (j == 0)
                    mvprintw(BOARD_START_Y, BOARD_START_X + j, "┌");
                else if (j == COLUMN * 4 - 4)
                    mvprintw(BOARD_START_Y, BOARD_START_X + j, "┐     ");
                else if (j != 0 && j % 4 == 0)
                    mvprintw(BOARD_START_Y, BOARD_START_X + j, "┬");
                else
                    mvprintw(BOARD_START_Y, BOARD_START_X + j, "─");
            }
            // 最后一行
            else if (i == ROW * 2 - 2) {
                if (j == 0)
                    mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "└");
                else if (j == COLUMN * 4 - 4)
                    mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "┘     ");
                else if (j != 0 && j % 4 == 0)
                    mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "┴");
                else
                    mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "─");
            }
            // 中间行
            else {
                if (i % 2 == 1) {
                    if (j % 4 == 0)
                        mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "│     ");
                } else {
                    if (j == 0)
                        mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "├");
                    else if (j == COLUMN * 4 - 4)
                        mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "┤     ");
                    else if (j != 0 && j % 4 == 0)
                        mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "┼");
                    else
                        mvprintw(BOARD_START_Y + i, BOARD_START_X + j, "─");
                }
            }
        }
    }
    for (int i = -1; i < 4; i++) {
        mvprintw(BOARD_START_Y + ROW * 2 + i, BOARD_START_X - 5, blank);
    }
    mvprintw(BOARD_START_Y + 2 * 3, BOARD_START_X + 3 * 4, "·");
    mvprintw(BOARD_START_Y + 2 * 3, BOARD_START_X + 11 * 4, "·");
    mvprintw(BOARD_START_Y + 2 * 11, BOARD_START_X + 3 * 4, "·");
    mvprintw(BOARD_START_Y + 2 * 11, BOARD_START_X + 11 * 4, "·");
    mvprintw(BOARD_START_Y + 2 * 7, BOARD_START_X + 7 * 4, "·");
    attroff(COLOR_PAIR(1));

    int mycolor = 2, enemycolor = 1;
    if (flag == 1) {
        mycolor = 1;
        enemycolor = 2;
    }
    attron(COLOR_PAIR(enemycolor));
    mvprintw(BOARD_START_Y - 4, BOARD_START_X, "●");
    mvprintw(BOARD_START_Y - 4, BOARD_START_X + 4, "%s", name2);
    attroff(COLOR_PAIR(enemycolor));

    attron(COLOR_PAIR(mycolor));
    mvprintw(BOARD_START_Y + ROW * 2 + 2, BOARD_START_X, "●");
    mvprintw(BOARD_START_Y + ROW * 2 + 2, BOARD_START_X + 4, "%s", name1);
    attroff(COLOR_PAIR(mycolor));
    refresh();
}

void drawChessMan(Chessman *mychess, Chessman *enemy, Chessman *computer, int flag)
{
    // flag:我方棋子颜色——1:黑子    2:白子
    init_pair(1, COLOR_BLACK, COLOR_YELLOW);
    init_pair(2, COLOR_WHITE, COLOR_YELLOW);

    // 绘制我的棋子
    attron(COLOR_PAIR(flag));
    for (int i = 0; i < mychess->count; i++) {
        if (mychess->pos_x[i] != -1 && mychess->pos_y[i] != -1) {
            mvprintw(BOARD_START_Y + 2 * mychess->pos_y[i], BOARD_START_X + mychess->pos_x[i] * 4, "  ");
            mvprintw(BOARD_START_Y + 2 * mychess->pos_y[i], BOARD_START_X + mychess->pos_x[i] * 4, "●");
        }
    }
    attroff(COLOR_PAIR(flag));

    // 绘制对方棋子
    flag = (flag == 1) ? 2 : 1;
    attron(COLOR_PAIR(flag));
    if (enemy == NULL) {
        // 电脑
        for (int i = 0; i < computer->count; i++) {
            if (computer->pos_x[i] != -1 && computer->pos_y[i] != -1) {
                mvprintw(BOARD_START_Y + 2 * computer->pos_y[i], BOARD_START_X + computer->pos_x[i] * 4, "  ");
                mvprintw(BOARD_START_Y + 2 * computer->pos_y[i], BOARD_START_X + computer->pos_x[i] * 4, "●");
            }
        }
    } else if (computer == NULL) {
        // 对方玩家
        for (int i = 0; i < enemy->count; i++) {
            if (enemy->pos_x[i] != -1 && enemy->pos_y[i] != -1) {
                mvprintw(BOARD_START_Y + 2 * enemy->pos_y[i], BOARD_START_X + enemy->pos_x[i] * 4, "  ");
                mvprintw(BOARD_START_Y + 2 * enemy->pos_y[i], BOARD_START_X + enemy->pos_x[i] * 4, "●");
            }
        }
    }
    attroff(COLOR_PAIR(flag));
    refresh();
}

int socket_init(const char *ip, const char *port)
{
    int serverfd = -1;
    serverfd = socket(AF_INET, SOCK_STREAM, 0);
    if (serverfd == -1) {
        ERRLOG("socket error");
    }

    struct sockaddr_in servaddr;
    socklen_t addrlen = sizeof(servaddr);
    servaddr.sin_family = AF_INET;
    // servaddr.sin_addr.s_addr = inet_addr("192.168.2.224");
    // servaddr.sin_port = htons(atoi("8888"));
    servaddr.sin_addr.s_addr = inet_addr(ip);
    servaddr.sin_port = htons(atoi(port));

    if (connect(serverfd, (struct sockaddr *)&servaddr, addrlen) == -1) {
        ERRLOG("connect error");
    }
    return serverfd;
}

/*返回值 1:持黑子 2:持白子*/
int findGame(int serverfd)
{
    mvprintw(CUR_Y_CENTER, CUR_X_CENTER - 10, "正在寻找对局...");
    refresh();
    Cmd msg;

    do {
        memset(&msg, 0, sizeof(Cmd));
        msg.cmd = 1;
        if (send(serverfd, &msg, sizeof(msg), 0) < 0) {
            ERRLOG("send error");
        }
        memset(&msg, 0, sizeof(Cmd));
        if (recv(serverfd, &msg, sizeof(msg), 0) < 0) {
            ERRLOG("recv error");
        }
    } while (msg.cmd == 0);
    if (msg.cmd == 100) {
        return 1; // 持黑子
    } else if (msg.cmd == 101) {
        return 2; // 持白子
    }
    return -1;
}

/*serverfd:若为人机，填-1*/
bool myMoveChess(int serverfd, Chessman *mychess, Chessman *enemy, int flag)
{
    //  计时线程
    int tmp = 1;
    pthread_t thread1;
    if (pthread_create(&thread1, NULL, timeCount, &tmp) == -1) {
        perror("pthread1-create");
    }
    // 信息打印
    mvprintw(BOARD_START_Y - 7, BOARD_START_X - 5, "        ");
    mvprintw(BOARD_START_Y + ROW * 2 + 5, BOARD_START_X - 5, "我方回合");
    refresh();

    // 等待落子
    MEVENT event;
    while (1) {
        if (countdown < 0) {
            clear();
            mvprintw(BOARD_START_Y + 2 * 20, BOARD_START_X + 20, "操作超时，你输掉了比赛");
            refresh();
            return TRUE;
        }
        int ch = getch();
        if (ch == KEY_MOUSE) {
            getmouse(&event);
            if (event.bstate & BUTTON1_PRESSED) {
                // 检测到鼠标左键按下事件
                mvprintw(1, 0, "Left button pressed at (%d, %d)\n", event.x, event.y);
                refresh();
            } else if (event.bstate & BUTTON1_RELEASED) {
                // 检测到鼠标左键释放事件
                mvprintw(1, 0, "Left button released at (%d, %d)\n", event.x, event.y);

                // 落点检测
                if (event.x <= 146 && event.y <= 38 && event.x >= 90 && event.y >= 10 && (event.x - 90) % 4 == 0 && event.y % 2 == 0) {
                    for (int i = 0; i <= mychess->count; i++) {
                        if (mychess->pos_x[i] == event.x && mychess->pos_y[i] == event.y) {
                            continue;
                        }
                        if (enemy->pos_x[i] == event.x && enemy->pos_y[i] == event.y) {
                            continue;
                        }
                    }

                    mychess->pos_x[mychess->count] = event.x;
                    mychess->pos_y[mychess->count] = event.y;
                    refresh();
                    pthread_cancel(thread1);
                    mvprintw(42, 135, "                ");
                    break;
                } else if (0) {
                    // 判断鼠标点击位置是否为对话框
                    // 移动光标到对话框开头
                    // 打开回显
                    // 等待用户输入
                }
            }
        }
    }

    // 打印棋子
    init_pair(1, COLOR_BLACK, COLOR_YELLOW);
    init_pair(2, COLOR_WHITE, COLOR_YELLOW);
    flag = flag == 1 ? 1 : 2;
    attron(COLOR_PAIR(flag));
    mvprintw(mychess->pos_y[mychess->count], mychess->pos_x[mychess->count], "●");
    refresh();
    attroff(COLOR_PAIR(flag));

    // 输赢判断
    Cmd msg;
    memset(&msg, 0, sizeof(msg));
    bool result = isvictory(mychess);
    msg.cmd = (result == TRUE ? 3 : 2);

    // 发送坐标
    msg.x = mychess->pos_x[mychess->count];
    msg.y = mychess->pos_y[mychess->count];
    if (serverfd != -1) {
        send(serverfd, &msg, sizeof(msg), 0);
    }

    mychess->count++;
    if (result) {
        mvprintw(BOARD_START_Y + ROW * 2 + 5, BOARD_START_X - 5, "游戏结束，我方胜利！");
        refresh();
        return TRUE;
    }
    mvprintw(BOARD_START_Y + ROW * 2 + 5, BOARD_START_X - 5, "                             ");
    refresh();
    return FALSE;
}

bool enemyMoveChess(int serverfd, Chessman *enemy, int flag)
{
    countdown = 60;
    mvprintw(BOARD_START_Y + 2 * 20, BOARD_START_X + 20, "                      ");
    mvprintw(BOARD_START_Y - 7, BOARD_START_X - 5, "对方回合");

    //  计时线程(打印对方时间)
    int tmp = 2;
    pthread_t thread1;
    if (pthread_create(&thread1, NULL, timeCount, &tmp) == -1) {
        perror("pthread1-create");
    }

    // 等待对方落子
    Cmd msg;
    do {
        memset(&msg, 0, sizeof(msg));
        int ret = recv(serverfd, &msg, sizeof(msg), 0);
        if (ret == -1) {
            ERRLOG("recv errror");
        }
        if (msg.cmd == 200 || msg.cmd == 300) {
            break;
        }
    } while (1);

    pthread_cancel(thread1);
    mvprintw(BOARD_START_Y - 4, 135, "                ");

    enemy->pos_x[enemy->count] = msg.x;
    enemy->pos_y[enemy->count] = msg.y;

    // 绘制对方棋子
    init_pair(1, COLOR_BLACK, COLOR_YELLOW);
    init_pair(2, COLOR_WHITE, COLOR_YELLOW);
    flag = flag == 1 ? 2 : 1;
    attron(COLOR_PAIR(flag));
    mvprintw(enemy->pos_y[enemy->count], enemy->pos_x[enemy->count], "●");
    attroff(COLOR_PAIR(flag));
    mvprintw(BOARD_START_Y - 7, BOARD_START_X - 5, "对方胜利");
    enemy->count++;
    refresh();

    if (msg.cmd == 300) {
        return TRUE;
    }
    return FALSE;
}

/*arg : 1-我方倒计时  2-对方倒计时*/
void *timeCount(void *arg)
{
    int flag = *(int *)arg;
    pthread_detach(pthread_self());
    countdown = 60;
    init_pair(1, COLOR_BLACK, COLOR_YELLOW);

    attron(COLOR_PAIR(1));
    do {
        if (flag == 1) {
            mvprintw(BOARD_START_Y + ROW * 2 + 2, BOARD_START_X + COLUMN * 3, "倒计时：%d", countdown);
        } else {
            mvprintw(BOARD_START_Y - 4, BOARD_START_X + COLUMN * 3, "倒计时：%d", countdown);
        }
        refresh();
        sleep(1);
    } while (--countdown);
    attroff(COLOR_PAIR(1));

    return NULL;
}

bool isvictory(Chessman *myself)
{
    if (myself->count >= 4) {

        // 行判断
        int count = 1;
        int cur_y = myself->pos_y[myself->count];
        int cur_x = myself->pos_x[myself->count] + 4;

        for (int j = 0; j < myself->count; j++) {
            if (cur_y == myself->pos_y[j] && myself->pos_x[j] == cur_x) {
                cur_x += 4;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        cur_x = myself->pos_x[myself->count] - 4;
        for (int j = 0; j < myself->count; j++) {
            if (cur_y == myself->pos_y[j] && myself->pos_x[j] == cur_x) {
                cur_x -= 4;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        // 列判断
        count = 1;
        cur_x = myself->pos_x[myself->count];
        cur_y = myself->pos_y[myself->count] + 2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_y += 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        cur_y = myself->pos_y[myself->count] - 2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_y -= 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        // 斜向判断——撇
        count = 1;
        cur_x = myself->pos_x[myself->count] + 4;
        cur_y = myself->pos_y[myself->count] - 2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_x += 4;
                cur_y -= 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        cur_x = myself->pos_x[myself->count] - 4;
        cur_y = myself->pos_y[myself->count] + 2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_x -= 4;
                cur_y += 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        // 斜向判断——捺
        count = 1;
        cur_x = myself->pos_x[myself->count] + 4;
        cur_y = myself->pos_y[myself->count] + 2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_x += 4;
                cur_y += 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }

        cur_x = myself->pos_x[myself->count]-4;
        cur_y = myself->pos_y[myself->count]-2;
        for (int j = 0; j < myself->count; j++) {
            if (cur_x == myself->pos_x[j] && myself->pos_y[j] == cur_y) {
                cur_x -= 4;
                cur_y -= 2;
                if (++count >= 5)
                    return TRUE;
                j = -1;
            }
        }
    }
    return FALSE;
}

void computerMove()
{
    return;
}