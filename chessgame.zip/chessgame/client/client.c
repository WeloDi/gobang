#include "chess.h"

int countdown; // 倒计时
int main(int argc, char const *argv[])
{
    if (argc != 3) {
        printf("Usage: ./server.c <ip> <port>\n");
        exit(-1);
    }
    int serverfd = socket_init(argv[1], argv[2]);
    init_window();
    int index = 0;
    do {
        index = menu();
        // index = 2;
        switch (index) {
        case 1: // 人机对战
            playerToComputer();
            break;
        case 2: // 玩家对战
            playerToPlayer(serverfd);
            break;
        case 0:
            endwin();
            break;
        default:
            break;
        }
    } while (index);

    return 0;
}

