#ifndef CHESS_H
#define CHESS_H
#include <arpa/inet.h>
#include <curses.h>
#include <locale.h>
#include <ncurses.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#define WIDTH 16
#define HIGHT 16
#define CUR_X_CENTER (COLS / 2)  // 窗口中心X坐标
#define CUR_Y_CENTER (LINES / 2) // 窗口中心Y坐标
#define BOARD_START_X 90         // 棋盘左上角X坐标
#define BOARD_START_Y 10         // 棋盘左上角Y坐标
#define ROW 15
#define COLUMN 15
#define NUM_MAN 113

#define ERRLOG(errmsg)                                                            \
    do {                                                                          \
        perror(errmsg);                                                           \
        printf("file : %s, func: %s, line : %d\n", __FILE__, __func__, __LINE__); \
        exit(-1);                                                                 \
    } while (0);

extern int countdown; // 倒计时
typedef struct Chessman {
    int pos_x[NUM_MAN];
    int pos_y[NUM_MAN];
    int count;
} Chessman;

// typedef struct Enemyman {
//     int pos_x;
//     int pos_y;
// } Enemyman;

typedef struct Cmd {
    int x;
    int y;
    int cmd; // 1:请求对局  2:确认落子  3:我方胜利     4:发送信息
} Cmd;

int getNum();
void init_window();
int menu();
void playerToComputer();
void playerToPlayer(int serverfd);

void drawChessBoard(char *name1, char *name2, int flag);
void drawChessMan(Chessman *mychess, Chessman *enemy, Chessman *computer, int flag);
int socket_init(const char *ip, const char *port);

int findGame(int serverfd);
void computerMove();
bool myMoveChess(int serverfd, Chessman *mychess, Chessman *enemy, int flag);
bool enemyMoveChess(int serverfd, Chessman *enemy, int flag);
void *timeCount(void *arg);
bool isvictory(Chessman *myself);
#endif